
import os
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader, ServiceContext,set_global_service_context
from llama_index.core import Settings




from constant.constants import model_config ,classification_config


from llama_index.llms.openai import OpenAI
from llama_index.multi_modal_llms.openai import OpenAIMultiModal
from llama_index.embeddings.openai import OpenAIEmbedding




#llm = OpenAI(model="gpt-3.5-turbo-0125", api_key=classification_config.OPENAI_API_KEY)
llm = OpenAI(model="gpt-4o-mini", api_key=classification_config.OPENAI_API_KEY)
# llm = OpenAI(model="gpt-4o", api_key=classification_config.OPENAI_API_KEY)
#llm = OpenAI(model="gpt-4o-2024-08-06", api_key=classification_config.OPENAI_API_KEY)


embed_model=OpenAIEmbedding(model="text-embedding-3-large", 
                             # dimensions=1024,
                             api_key=classification_config.OPENAI_API_KEY,
                             )



service_context = ServiceContext.from_defaults(
    llm=llm, 
    embed_model=embed_model,
)



Settings.llm = llm
Settings.embed_model = embed_model





