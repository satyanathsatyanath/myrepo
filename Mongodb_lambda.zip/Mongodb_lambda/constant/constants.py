from dataclasses import dataclass


@dataclass
class Model_Configuration:
    CUDA_MODEL: str
    CUDA_EMBEDDING: str
    CONTEXT_WINDOW: int
    MAX_NEW_TOKENS: int
    TEMPERATURE: float
    LLM_MODEL_NAME: str
    LLM_MODEL_NAME_2: str
    LLM_MODEL_NAME_3: str
    LLM_TOKENIZER_NAME: str
    EMBEDDING_MODEL_NAME: str
    EMBEDDING_MODEL_NAME_2: str
    EMBEDDING_MODEL_NAME_3: str


model_config = Model_Configuration(
    CUDA_MODEL="cuda:1",
    CUDA_EMBEDDING="cuda:1",
    CONTEXT_WINDOW=4096,
    MAX_NEW_TOKENS=500,
    TEMPERATURE=0.0,
    LLM_MODEL_NAME="HuggingFaceH4/zephyr-7b-alpha",
    LLM_MODEL_NAME_2="",
    LLM_MODEL_NAME_3="",
    LLM_TOKENIZER_NAME="HuggingFaceH4/zephyr-7b-alpha",
    EMBEDDING_MODEL_NAME="BAAI/bge-small-en-v1.5",
    EMBEDDING_MODEL_NAME_2="BAAI/bge-large-en-v1.5",
    EMBEDDING_MODEL_NAME_3="",
)


@dataclass
class Classication_Configuration:
    CUDA_GPU: int
    MEMORY_LIMIT: int
    CLASSIFICATION_MODEL: str
    TF_DEVICE: str
    GPU: str
    OPENAI_API_KEY: str


classification_config = Classication_Configuration(
    CUDA_GPU=0,
    MEMORY_LIMIT=20480,
    CLASSIFICATION_MODEL="Model7_loss_27_trainacc_95_valloss_34val_acc_93_epochs_53.h5",
    TF_DEVICE="/GPU:0",
    GPU="GPU",
    OPENAI_API_KEY="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",  # Amnet SE API
)
