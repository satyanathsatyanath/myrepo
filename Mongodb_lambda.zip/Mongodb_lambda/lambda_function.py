
from llama_index.core import VectorStoreIndex

from llama_index.core import (
    VectorStoreIndex,
    load_index_from_storage,
    StorageContext,
)

from llama_index.core.tools import QueryEngineTool, ToolMetadata

from llama_index.agent.openai import OpenAIAgent

import pickle

from llama_index.vector_stores.mongodb import MongoDBAtlasVectorSearch

from main import llm

import json

import pymongo


def handler(event,context):
    data=json.loads(event['body'])
    query = data["Question"]
    output_text = "" 

    client = pymongo.MongoClient("mongodb+srv://satyanath:satyanath@cluster0.r5jug.mongodb.net/")

    vector_store_all = MongoDBAtlasVectorSearch(
            client,
            db_name="www_stmarkvillage_org_index_all_docs",
            collection_name="all_docs_collection",
            vector_index_name="vector_index",)

    vector_store_table = MongoDBAtlasVectorSearch(
        client,
        db_name="www_stmarkvillage_org_index_all_docs",
        collection_name="table_docs_collection",
        vector_index_name="vector_index",)

    all_docs_index = VectorStoreIndex.from_vector_store(vector_store_all)
    table_docs_index = VectorStoreIndex.from_vector_store(vector_store_table)

    # print("entered into inference")
    query_engine_all_docs = all_docs_index.as_query_engine(similarity_top_k=5)
    query_engine_table_docs = table_docs_index.as_query_engine(similarity_top_k=5)


    query_engine_tools = [
                QueryEngineTool(
                    query_engine=query_engine_all_docs,
                    metadata=ToolMetadata(
                        name="all_docs",
                        description=(
                            "Provides General information and services offered by St. Mark Village"
                            "Provide the response in a human like and caring manner and in a format suitable for elderly people" 
                            "Use a detailed plain text question as input to the tool."
                            "Understand the query well and try to fetch information for latest effective date and if it includes numerical values from the context "
                        ),
                    ),
                ),
                QueryEngineTool(
                    query_engine=query_engine_table_docs,
                    metadata=ToolMetadata(
                        name="table_docs",
                        description=(
                            "Provides Financial costs or pricing related information and services offered by St. Mark Village"
                            "Numeric data such as costs, rates, statistics, or any quantitative information. "
                            "Financial information including fees, budgets, pricing structures, or financial policies. "
                            "Information presented in tables or structured formats within the documents. "
                            "Complex or multi-part questions that may require analysis of various data points. "
                            "Use a clear, detailed question as input. For best results with numeric or or  financial queries, "
                            "be specific about the type of data you're looking for (e.g., exact figures, ranges, percentages). "
                            "When asking about tabular data, specify which aspects of the table you're interested in."
                            "Understand the query well and try to fetch information for latest effective date and if it includes numerical values from the context "
                        ),
                    ),
                ),

            ]
    

    agent_openai = OpenAIAgent.from_tools(
        query_engine_tools,
        llm=llm,
        verbose=True,
    )

    response = agent_openai.chat(query)
    
    output_text=response.response


    return json.dumps(output_text)