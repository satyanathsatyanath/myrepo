# import runpod
#  # Required.
# import os
# import boto3
# import base64
# s3 = boto3.client('s3',aws_access_key_id='AKIA3YEKPQYCBMCA6DXC',aws_secret_access_key='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')

# def handler(job):
#     # Decode the image data from the job
#     pdf=job["input"]

#     image_data = base64.b64decode(pdf['prompt'])
#     print("hi------------->:",pdf['prompt'])
#     # Save the image to the /tmp directory
#     image_path = '/tmp/new.pdf'
#     with open(image_path, 'wb') as f:
#         f.write(image_data)
#     print(job)
    
#     if os.path.exists(image_path):
#         print("Yes")
#         # Check the size of the image file in bytes
#         file_size = os.path.getsize(image_path)
#         print("File size:", file_size, "bytes")
        
#         # Read the file contents
#         with open(image_path, 'rb') as f:
#             file_contents = f.read()
        
#         # Upload the file contents to S3
#         s3.put_object(Bucket='mbaaccess', Key='new.pdf', Body=file_contents)
    
#     # Perform any necessary processing on the image
#     # ...
    
#     return {
#         'statusCode': 200,
#         'body': 'Image saved to /tmp directory and uploaded to S3'
#     }
# runpod.serverless.start({"handler": handler}) 



print("1 started")
import runpod
print("2 started")
import os
print("3 started")
import boto3
print("4 started")
import base64
print("5 started")
from unstructured.partition.pdf import partition_pdf
print("6 started")
from unstructured.staging.base import convert_to_dict
print("7 started")
s3 = boto3.client('s3',aws_access_key_id='AKIA3YEKPQYCBMCA6DXC',aws_secret_access_key='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')
print("8 started")
def handler(job):
    print("os started")
    os.makedirs('/tmp', exist_ok=True)
    print("os2 started")
    job_input = job["input"]  # Access the input from the request.
    print("job_in started")
    pdf  = job_input["prompt"]
    print("9 started")
    pdf_data = base64.b64decode(pdf)
    print("hi------------->")
    # Save the image to the /tmp directory
    pdf_path = '/tmp/new.pdf'
    print("10 started")
    with open(pdf_path, 'wb') as f:
        f.write(pdf_data)
    print("11 started")
 
    # pdf_document = fitz.open(pdf_path)
 
    # # Get the first page
    # first_page = pdf_document[0]
   
    # # Extract text from the first page
    # text = first_page.get_text()
 
    # if os.path.exists(pdf_path):
    #     print("Yes")
    #     # Check the size of the image file in bytes
    #     file_size = os.path.getsize(pdf_path)
    #     print("File size:", file_size, "bytes")
       
    #     # Read the file contents
    #     with open(pdf_path, 'rb') as f:
    #         file_contents = f.read()
       
    #     # Upload the file contents to S3
    #     s3.put_object(Bucket='mbaaccess', Key='new.pdf', Body=file_contents)
    #     return "uploaded to s3"
 
    
    elements = partition_pdf(filename = pdf_path,
                         infer_table_structure=True,
                         strategy='hi_res'
                         )
    print("12")
   
    all_elements_dict = convert_to_dict(elements)
    print("13 started")
    return all_elements_dict
 
runpod.serverless.start({"handler": handler})  # Required.
 